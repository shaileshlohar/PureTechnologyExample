package com.zensar.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Geo {
 
	@Id
	private String lat; 
   private String lng;
  
   @OneToOne(mappedBy = "geo")
   private Address address;
   
   
public String getLat() {
	return lat;
}
public void setLat(String lat) {
	this.lat = lat;
}
public String getLng() {
	return lng;
}
public void setLng(String lng) {
	this.lng = lng;
}
   
   
}
