package com.zensar.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.zensar.entity.Employee;

public interface Mydao extends JpaRepository<Employee, Integer> {

	public Employee getByUsername(String username);
	
	@Query(name ="update table Employee set duplicate_Count = duplicate_Count + 1 where id = ?")
	public String updateDuplicateCount(Integer Id);
}
