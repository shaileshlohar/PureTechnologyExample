package com.zensar.service;

import java.io.IOException;
import java.util.List;

import com.zensar.entity.Employee;


public interface Myservice {

	List<Employee> findAllEmployee() throws IOException;
	Employee addEmployee(Employee employee);
}
