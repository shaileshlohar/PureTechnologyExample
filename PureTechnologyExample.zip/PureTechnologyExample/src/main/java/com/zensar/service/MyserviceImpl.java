package com.zensar.service;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.opencsv.CSVWriter;
import com.zensar.dao.Mydao;
import com.zensar.entity.Employee;

public class MyserviceImpl implements Myservice {

	@Autowired
	private Mydao mydao;

	@Override
	public List<Employee> findAllEmployee() throws IOException {
		// TODO Auto-generated method stub
		CSVWriter writer = new CSVWriter(new FileWriter("D://employee.csv"));
		List<Employee> employees = mydao.findAll();
		for (Employee employee : employees) {

			writer.writeAll((Iterable<String[]>) employee);
			writer.flush();
		}
		return employees;
	}

	@Override
	public Employee addEmployee(Employee employee) {

		Employee emp2 = null;
		String username = employee.getUsername();
		Employee emp = mydao.getByUsername(username);
		if (!username.equals(emp.getUsername())) {
			emp2 = mydao.save(employee);
		} else {
			mydao.updateDuplicateCount(employee.getId());
		}

		return emp2;
	}

}
