package com.zensar.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.entity.Employee;
import com.zensar.service.Myservice;

@RestController
public class Mycontroller {

	@Autowired
	private Myservice myservice;

	@GetMapping(value = "/employee", produces = "application/json")
	public List<Employee> getAllEmployee() throws IOException {
		return myservice.findAllEmployee();
	}

	@PostMapping("/employee/add")
	public String addEmployee(@RequestBody Employee employee) {
		myservice.addEmployee(employee);
		return "Employee is added";

	}
}
